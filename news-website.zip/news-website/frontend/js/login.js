document.addEventListener('DOMContentLoaded', () => {
  // If already logged in, redirect to dashboard
  if (localStorage.getItem('admin_token')) {
    window.location.href = '/admin/dashboard.html';
    return;
  }

  document.getElementById('login-form')?.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = document.getElementById('login-btn');
    const errEl = document.getElementById('login-error');
    
    btn.disabled = true;
    btn.textContent = 'Signing in...';
    if (errEl) errEl.style.display = 'none';

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('admin_token', data.token);
        localStorage.setItem('admin_user', JSON.stringify(data.user));
        window.location.href = '/admin/dashboard.html';
      } else {
        if (errEl) { errEl.textContent = data.message || 'Invalid credentials'; errEl.style.display = 'block'; }
      }
    } catch (err) {
      if (errEl) { errEl.textContent = 'Connection error. Is the server running?'; errEl.style.display = 'block'; }
    } finally {
      btn.disabled = false;
      btn.textContent = 'Sign In';
    }
  });
});
