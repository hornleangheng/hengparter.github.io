# 📰 NewsHub - Full-Stack News Website

A complete, production-ready news website similar to kohsantepheapdaily.com.kh, built with:
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js + Express
- **Database**: MongoDB

---

## 📁 Project Structure

```
news-website/
├── backend/
│   ├── models/
│   │   ├── Article.js       # Article schema
│   │   ├── User.js          # User schema (admin)
│   │   └── Category.js      # Category schema
│   ├── routes/
│   │   ├── articles.js      # CRUD API for articles
│   │   ├── auth.js          # Login/register/JWT
│   │   ├── categories.js    # Category management
│   │   └── upload.js        # Image upload (multer)
│   ├── middleware/
│   │   └── auth.js          # JWT auth middleware
│   ├── uploads/             # Uploaded images stored here
│   ├── server.js            # Main Express server
│   ├── seed.js              # Database seeder
│   ├── .env.example         # Environment variables template
│   └── package.json
└── frontend/
    ├── css/
    │   ├── style.css        # Main frontend styles
    │   └── admin.css        # Admin panel styles
    ├── js/
    │   ├── main.js          # Frontend JavaScript
    │   ├── admin.js         # Admin panel JS
    │   └── login.js         # Login JS
    ├── admin/
    │   ├── login.html       # Admin login page
    │   ├── dashboard.html   # Admin dashboard
    │   ├── articles.html    # Article management
    │   ├── create.html      # Create/edit article
    │   └── categories.html  # Category management
    ├── pages/
    │   ├── about.html
    │   ├── contact.html
    │   └── privacy.html
    ├── index.html           # Homepage
    ├── article.html         # Article detail page
    ├── category.html        # Category page
    └── search.html          # Search results page
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v16+ ([download](https://nodejs.org))
- **MongoDB** v5+ ([download](https://www.mongodb.com/try/download/community))
- **Git** (optional)

---

### Step 1: Install MongoDB

**macOS (Homebrew):**
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

**Ubuntu/Debian:**
```bash
sudo apt install -y mongodb
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

**Windows:**
Download installer from https://www.mongodb.com/try/download/community

---

### Step 2: Setup the Backend

```bash
cd news-website/backend

# Copy environment file
cp .env.example .env

# Install dependencies
npm install

# Seed the database (creates admin user + sample articles)
npm run seed
```

**Seeded credentials:**
- Username: `admin`
- Password: `Admin@123`

---

### Step 3: Start the Server

```bash
npm run dev     # Development (with auto-reload via nodemon)
# OR
npm start       # Production
```

The app will be available at: **http://localhost:5000**

---

## 🌐 Pages

| URL | Description |
|-----|-------------|
| `http://localhost:5000` | Homepage |
| `http://localhost:5000/article.html?slug=...` | Article detail |
| `http://localhost:5000/category.html?cat=Politics` | Category page |
| `http://localhost:5000/search.html?q=keyword` | Search results |
| `http://localhost:5000/admin/login.html` | Admin login |
| `http://localhost:5000/admin/dashboard.html` | Admin dashboard |
| `http://localhost:5000/admin/articles.html` | Manage articles |
| `http://localhost:5000/admin/create.html` | Create article |
| `http://localhost:5000/admin/categories.html` | Manage categories |

---

## 🔌 REST API Reference

### Articles
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/articles` | List articles (paginated) | No |
| GET | `/api/articles?search=q` | Search articles | No |
| GET | `/api/articles?category=Politics` | Filter by category | No |
| GET | `/api/articles?featured=true` | Get featured articles | No |
| GET | `/api/articles/popular` | Get most-viewed articles | No |
| GET | `/api/articles/:slug` | Get article by slug | No |
| GET | `/api/articles/id/:id` | Get article by ID | No |
| POST | `/api/articles` | Create article | ✅ JWT |
| PUT | `/api/articles/:id` | Update article | ✅ JWT |
| DELETE | `/api/articles/:id` | Delete article | ✅ JWT |

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login → returns JWT token |
| POST | `/api/auth/register` | Register new admin |
| GET | `/api/auth/me` | Get current user |

### Categories & Upload
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/categories` | List all categories | No |
| POST | `/api/categories` | Create category | ✅ JWT |
| DELETE | `/api/categories/:id` | Delete category | ✅ JWT |
| POST | `/api/upload` | Upload image | ✅ JWT |

### Query Parameters for Articles
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)
- `category` - Filter by category name
- `search` - Full-text search
- `featured` - Set to `true` for featured only

---

## ⚙️ Environment Variables

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/newsdb
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
NODE_ENV=development
```

---

## 🔐 Admin Panel

1. Go to `http://localhost:5000/admin/login.html`
2. Login with `admin` / `Admin@123`
3. Use the dashboard to:
   - ✏️ Create, edit, delete articles
   - 🖼️ Upload images or use image URLs
   - 📂 Manage categories
   - ⭐ Mark articles as featured (shows in homepage slider)

---

## 🌍 Deployment

### Option 1: Deploy to Railway (Recommended - Free)

1. Push code to GitHub
2. Go to [railway.app](https://railway.app)
3. New Project → Deploy from GitHub
4. Add MongoDB service (MongoDB Atlas or Railway's MongoDB plugin)
5. Set environment variables:
   ```
   MONGODB_URI=your_mongodb_connection_string
   JWT_SECRET=your_strong_secret_key
   NODE_ENV=production
   ```

### Option 2: Deploy to Render (Free)

1. Push to GitHub
2. Go to [render.com](https://render.com)
3. New Web Service → Connect GitHub repo
4. Build Command: `cd backend && npm install`
5. Start Command: `cd backend && npm start`
6. Set environment variables

### Option 3: VPS/Cloud Server (Ubuntu)

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install MongoDB
sudo apt install -y mongodb
sudo systemctl start mongodb

# Clone/upload your project
cd /var/www/news-website/backend
npm install --production

# Install PM2 process manager
npm install -g pm2
pm2 start server.js --name newshub
pm2 startup
pm2 save

# Install Nginx
sudo apt install -y nginx

# Configure Nginx reverse proxy
sudo nano /etc/nginx/sites-available/newshub
```

**Nginx config:**
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    client_max_body_size 10M;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/newshub /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# SSL with Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

---

## 🎨 Customization

### Change Website Name/Logo
Edit `frontend/index.html` and search for `NewsHub` to replace with your name.

### Add New Categories
Go to Admin Panel → Categories → Add Category, or add to the `seed.js` file.

### Modify Colors
In `frontend/css/style.css`, change the CSS variables at the top:
```css
:root {
  --primary: #c0392b;       /* Main red color */
  --secondary: #2c3e50;     /* Dark blue/navy */
  --accent: #f39c12;        /* Orange accent */
}
```

### Add Khmer Language Support
The CSS already includes the Khmer font variable:
```css
--font-khmer: 'Noto Serif Khmer', serif;
```
Add this to Google Fonts and use as needed for Khmer content.

---

## 📦 Dependencies

### Backend
| Package | Purpose |
|---------|---------|
| express | Web framework |
| mongoose | MongoDB ODM |
| bcryptjs | Password hashing |
| jsonwebtoken | JWT authentication |
| multer | File/image uploads |
| cors | Cross-origin requests |
| dotenv | Environment variables |

---

## 🐛 Troubleshooting

**MongoDB connection failed:**
```bash
sudo systemctl start mongodb
# or
mongod --dbpath /data/db
```

**Port 5000 in use:**
```bash
lsof -ti:5000 | xargs kill
```

**Images not loading:**
- Ensure the `backend/uploads/` directory exists
- Check file permissions: `chmod 755 backend/uploads`

**JWT errors:**
- Make sure `JWT_SECRET` is set in your `.env` file
- Ensure you're sending `Authorization: Bearer <token>` header

---

## 📄 License

MIT — Free to use for personal and commercial projects.

---

Built with ❤️ using Node.js + MongoDB + Vanilla JS
